const db = require('../config/db');

const Keyword = {
    getAllKeyword: (callback) => {
        const query = 'SELECT * FROM add_keyword where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getKeywordById: (id, callback) => {
        const query = 'SELECT * FROM add_keyword WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    findWorkDetails: (workname) => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM add_keyword WHERE full_name = ? AND status = 1';
            db.query(query, [workname], (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database query error', data: err });
                }
                resolve(results);
            });
        });
    },

    addKeyword: (infoData, callback) => {
        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO add_keyword (keyword_name, selected_topic, data_available_from, data_available_to, remarks, mapping_keywords, selected_works) VALUES (?, ?, ?, ?, ?, ?, ?)';
            const values = [infoData.keyword_name, infoData.selected_topic, infoData.data_available_from, infoData.data_available_to, infoData.remarks, infoData.mapping_keywords, infoData.selected_works];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                resolve(results);
            });
        });
    },
    
    updateKeyword: (keyword_id, updatedData, callback) => {
        const query = 'UPDATE add_keyword SET ? WHERE id = ?';
        db.query(query, [updatedData, keyword_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },

    findKeywordDetails: (mapname,topicType) => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM bulk_keyword_upload WHERE mapped_name = ? AND topic_type = ? AND status = 1';
            db.query(query, [mapname,topicType], (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database query error', data: err });
                }
                resolve(results);
            });
        });
    },

    insertMapKeyword: (infoData, callback) => {
        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO bulk_keyword_upload (mapped_name, topic_type) VALUES (?, ?)';
            const values = [infoData.mapped_name, infoData.topic_type];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                resolve(results);
            });
        });
    },
    
};

module.exports = Keyword;
