const db = require('../config/db');

const Company = {
    getAllCompanies: (callback) => {
        const query = 'SELECT * FROM companies where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getCompanyById: (id, callback) => {
        const query = 'SELECT * FROM companies WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    findCompanyDetails: (companyname) => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM companies WHERE company_name = ? AND status = 1';
            db.query(query, [companyname], (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database query error', data: err });
                }
                resolve(results);
            });
        });
    },

    insertCompany: (infoData, callback) => {
        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO companies (company_name, company_url, post_panel_url, cms_url, description) VALUES (?, ?, ?, ?, ?)';
            const values = [infoData.company_name, infoData.company_url, infoData.post_panel_url, infoData.cms_url, infoData.description];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                resolve(results);
            });
        });
    },
    
    updateCompany: (company_id, updatedData, callback) => {
        const query = 'UPDATE companies SET ? WHERE id = ?';
        db.query(query, [updatedData, company_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },
    
};

module.exports = Company;
