const db = require('../config/db');

const Source = {
    getAllOrigin: (callback) => {
        const query = 'SELECT * FROM source_origin where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getoriginById: (id, callback) => {
        const query = 'SELECT * FROM source_origin WHERE source_type_id = ?';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    findOriginDetails: (originname) => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM source_origin WHERE source_origin_name = ? AND status = 1';
            db.query(query, [originname], (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database query error', data: err });
                }
                resolve(results);
            });
        });
    },

    insertOrigin: (infoData, callback) => {
        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO source_origin (source_type_id, source_origin_name, source_origin_url ) VALUES (?, ?, ?)';
            const values = [infoData.source_type_id, infoData.source_origin_name, infoData.source_origin_url];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                resolve(results);
            });
        });
    },
    
    updateOrigin: (origin_id, updatedData, callback) => {
        const query = 'UPDATE source_origin SET ? WHERE id = ?';
        db.query(query, [updatedData, origin_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },

    getAllSource: (callback) => {
        const query = 'SELECT * FROM add_source where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getsourceById: (id, callback) => {
        const query = 'SELECT * FROM add_source WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    // addSourceDetails: async (source_type_id, sourceDetails) => {
    //     try {
    //         const query = `
    //             INSERT INTO add_source_details (
    //                 source_type_id,
    //                 source_origin_id,
    //                 journal_name,
    //                 journal_link,
    //                 journal_EISSN,
    //                 conference_name,
    //                 conference_dates,
    //                 conference_venue,
    //                 conference_PDF,
    //                 department_name,
    //                 source_link,
    //                 Data_available_From,
    //                 Data_available_To,
    //                 subjects,
    //                 Remarks
    //             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    //         `;
    
    //         const values = [
    //             source_type_id,
    //             sourceDetails.source_origin_id,
    //             sourceDetails.journal_name,
    //             sourceDetails.journal_link,
    //             sourceDetails.journal_EISSN,
    //             sourceDetails.conference_name,
    //             sourceDetails.conference_dates,
    //             sourceDetails.conference_venue,
    //             sourceDetails.conference_PDF,
    //             sourceDetails.department_name,
    //             sourceDetails.source_link,
    //             sourceDetails.Data_available_From,
    //             sourceDetails.Data_available_To,
    //             sourceDetails.subjects,
    //             sourceDetails.Remarks
    //         ];

    //         db.query(query, values, (err, results) => {
    //             if (err) {
    //                 return reject({ statusCode: 500, message: 'Database insert error', data: err });
    //             }
    //             console.log(`results`,results)
    //             resolve(results);
    //         });
    //     } catch (error) {
    //         console.error('Error in addSourceDetails:', error);
    //         throw error;
    //     }
    // },

    addSourceDetails: (source_type_id, sourceDetails, callback) => {
        return new Promise((resolve, reject) => {
            const query = `
                INSERT INTO add_source_details (
                    source_type_id,
                    source_origin_id,
                    journal_name,
                    journal_link,
                    journal_EISSN,
                    conference_name,
                    conference_dates,
                    conference_venue,
                    conference_PDF,
                    department_name,
                    source_link,
                    Data_available_From,
                    Data_available_To,
                    subjects,
                    Remarks
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;
    
            const values = [
                source_type_id,
                sourceDetails.source_origin_id,
                sourceDetails.journal_name,
                sourceDetails.journal_link,
                sourceDetails.journal_EISSN,
                sourceDetails.conference_name,
                sourceDetails.conference_dates,
                sourceDetails.conference_venue,
                sourceDetails.conference_PDF,
                sourceDetails.department_name,
                sourceDetails.source_link,
                sourceDetails.Data_available_From,
                sourceDetails.Data_available_To,
                sourceDetails.subjects,
                sourceDetails.Remarks
            ];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                console.log(`results`,results.insertId)
                resolve(results.insertId);
            });
        });
    },
    
    addSource: async (sourceDetailsId, sourceTypeId, mappingKeywords, selectedWorks) => {

        return new Promise((resolve, reject) => {
            const query = `
                INSERT INTO add_source (source_details_id, source_type_id, mapping_keywords, selected_works) VALUES (?, ?, ?, ?)
            `;
    
            const values = [
                sourceDetailsId,
                sourceTypeId,
                JSON.stringify(mappingKeywords),
                JSON.stringify(selectedWorks)
            ];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                console.log(`results`,results.insertId)
                resolve(results.insertId);
            });
        });
    }
    
}

module.exports = Source;
