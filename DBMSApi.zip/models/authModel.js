const db = require('../config/db');
const nodemailer = require('nodemailer');
const config = require('../config/jwtConfig');

const Auth = {
  getAllUsers: (callback) => {
    const query = 'SELECT * FROM users where status=1';
    db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query error', data: err });
        }
        callback(null, results);
    });
},

getUserById: (id, callback) => {
    const query = 'SELECT * FROM users WHERE id = ?';
    db.query(query, [id], (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query error', data: err });
        }
        callback(null, results[0]);
    });
},

findOne: (conditions, callback) => {
  const query = 'SELECT * FROM users WHERE user_name = ? LIMIT 1';
  db.query(query, [conditions.user_name], (err, results) => {
      if (err) {
          return callback({ statusCode: 500, message: 'Database query error', data: err });
      }
      callback(null, results[0]);
  });
},

findOneByUsername: (username, callback) => {
  const query = 'SELECT * FROM users WHERE user_name = ?';
  db.query(query, [username], (err, results) => {
      if (err) return callback(err);
      if (results.length === 0) return callback(null, null);
      return callback(null, results[0]);
  });
},

createUser: (userData, callback) => {
  const query = 'INSERT INTO users (full_name, user_name, password, role_type) VALUES (?, ?, ?, ?)';
  const values = [userData.full_name, userData.user_name, userData.password, userData.role_type];
  db.query(query, values, (err, result) => {
      if (err) {
          return callback(err, null);
      }
      callback(null, result);
  });
},

sendVerificationEmail: async (email, token) => {
  const transporter = nodemailer.createTransport(config.smtpConfig);
  const mailOptions = {
    from: 'your-email@example.com',
    to: 'jayaram_v@magnusgroup.co.in',
    subject: 'Email Verification',
    html: `Please verify your email by clicking the following link: <a href="http://localhost:3000/verify-email?token=${token}">Verify Email</a>`
  };
  await transporter.sendMail(mailOptions);
},

findByProfile: function(userId) {
    return new Promise((resolve, reject) => {
        const query = 'SELECT * FROM user_profile WHERE user_id = ?';
        db.query(query, [userId], (err, results) => {
            if (err) {
                return reject(err);
            }
            if (results.length === 0) {
                return resolve(null);
            }
            resolve(results[0]);
        });
    });
},

updateProfileData: function(userId, userData, profileData) {
    const self = this;
    return new Promise(async (resolve, reject) => {
        try {
            const userQuery = 'UPDATE users SET ? WHERE id = ?';
            const profileInsertQuery = `
                INSERT INTO user_profile (user_id, contact_no, address, country, about)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                contact_no = VALUES(contact_no),
                address = VALUES(address),
                country = VALUES(country),
                about = VALUES(about)`;

            const profileUpdateQuery = `
                UPDATE user_profile
                SET contact_no = ?, address = ?, country = ?, about = ?
                WHERE user_id = ?`;

            // Start transaction
            await db.beginTransaction();

            // Check if userData is not empty
            if (Object.keys(userData).length > 0) {
                // Update user data
                await db.query(userQuery, [userData, userId]);
            }

            // Check if user profile exists
            const existingProfile = await self.findByProfile(userId);

            if (existingProfile) {
                // Update profile data
                await db.query(profileUpdateQuery, [
                    profileData.contact_no,
                    profileData.address,
                    profileData.country,
                    profileData.about,
                    userId
                ]);
            } else {
                // Insert new profile data
                await db.query(profileInsertQuery, [
                    userId,
                    profileData.contact_no,
                    profileData.address,
                    profileData.country,
                    profileData.about
                ]);
            }

            // Commit transaction
            await db.commit();
            resolve({ message: 'User and profile updated successfully' });
        } catch (err) {
            await db.rollback();
            reject(err);
        }
    });
},

updatePasswordData: (userId, passData, callback) => {
    const query = 'UPDATE users SET ? WHERE id = ?';
    db.query(query, [passData, userId], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results);
    });
  },

  insertLogInfo: (logData) => {
    return new Promise((resolve, reject) => {
        const query = 'INSERT INTO user_logs (user_id, ip_address, log_type) VALUES (?, ?, ?)';
        const values = [logData.user_id, logData.localIpAddress, logData.log_type];

        db.query(query, values, (err, results) => {
            if (err) {
                return reject({ statusCode: 500, message: 'Database insert error', data: err });
            }
            resolve(results);
        });
    });
  },

  getAllLogs: (callback) => {
    return new Promise((resolve, reject) => {
        const query = 'SELECT * FROM user_logs ORDER BY 1 DESC';
        db.query(query, (err, results) => {
            if (err) {
                return reject({ statusCode: 500, message: 'Database query error', data: err });
            }
            resolve(results);
        });
    });
  },

  getLogById: (userId) => {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT *
            FROM user_logs
            WHERE user_id = ? ORDER BY 1 DESC`;
        db.query(query, [userId], (err, results) => {
            if (err) {
                return reject({ statusCode: 500, message: 'Database query error', data: err });
            }
            if (results.length === 0) {
                return resolve(null);
            }
            resolve(results);
        });
    });
  },
  
};

module.exports = Auth;
