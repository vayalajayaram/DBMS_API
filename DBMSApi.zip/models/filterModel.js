const db = require('../config/db');

const Source = {
    getAllDataSet: (callback) => {
        const query = 'SELECT * FROM filter_data_set where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getDataSetById: (id, callback) => {
        const query = 'SELECT * FROM filter_data_set WHERE id = ? AND status = 1';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    findDatasetDetails: (datasetname) => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM filter_data_set WHERE dataset_name = ? AND status = 1';
            db.query(query, [datasetname], (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database query error', data: err });
                }
                resolve(results);
            });
        });
    },

    insertDataset: (infoData, callback) => {
        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO filter_data_set (dataset_name, description ) VALUES (?, ?)';
            const values = [infoData.dataset_name, infoData.description];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                resolve(results);
            });
        });
    },
    
    updateDataSet: (dataset_id, updatedData, callback) => {
        const query = 'UPDATE filter_data_set SET ? WHERE id = ?';
        db.query(query, [updatedData, dataset_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },

    getAllSetRules: (callback) => {
        const query = 'SELECT * FROM filter_data_set_rules where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getSetRulesById: (id, callback) => {
        const query = 'SELECT * FROM filter_data_set_rules WHERE id = ? AND status = 1';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },
    
    addSetRules:(infoData, callback) => {
        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO filter_data_set_rules (filter_rule_name, data_set_id, data_type_id, selected_works, blacklist_whitelist, filter, description) VALUES (?, ?, ?, ?, ?, ?, ?)';
            const values = [infoData.filter_rule_name, infoData.data_set_id, infoData.data_type_id, infoData.selected_works, infoData.blacklist_whitelist, infoData.filter, infoData.description];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                resolve(results);
            });
        });
    },

    updatesetRules: (datasetrule_id, updatedData, callback) => {
        const query = 'UPDATE filter_data_set_rules SET ? WHERE id = ?';
        db.query(query, [updatedData, datasetrule_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },
    
}

module.exports = Source;
