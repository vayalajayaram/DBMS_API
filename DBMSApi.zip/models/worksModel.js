const db = require('../config/db');

const Work = {
    getAllWorks: (callback) => {
        const query = 'SELECT * FROM works where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getWorkById: (id, callback) => {
        const query = 'SELECT * FROM works WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    findWorkDetails: (workname) => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM works WHERE full_name = ? AND status = 1';
            db.query(query, [workname], (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database query error', data: err });
                }
                resolve(results);
            });
        });
    },

    insertWork: (infoData, callback) => {
        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO works (full_name, short_name, company_id, manager_id, team_lead_id, team_member_id) VALUES (?, ?, ?, ?, ?, ?)';
            const values = [infoData.full_name, infoData.short_name, infoData.company_id, infoData.manager_id, infoData.team_lead_id, infoData.team_member_id];

            db.query(query, values, (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database insert error', data: err });
                }
                resolve(results);
            });
        });
    },
    
    updateWork: (work_id, updatedData, callback) => {
        const query = 'UPDATE works SET ? WHERE id = ?';
        db.query(query, [updatedData, work_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },
    
};

module.exports = Work;
