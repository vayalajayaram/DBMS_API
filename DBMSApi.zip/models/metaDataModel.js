const db = require('../config/db');

const Meta = {
    getAllRoles: (callback) => {
        const query = 'SELECT * FROM roles where role_status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    findRoles: (shname,rolename, roletype) => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM roles WHERE short_name IN (?) OR role_name IN (?) OR role_type IN (?) AND role_status=1';
            db.query(query, [shname, rolename, roletype], (err, results) => {
                if (err) {
                    return reject({ statusCode: 500, message: 'Database query error', data: err });
                }
                resolve(results);
            });
        });
    },

    insertRoles: (roleData, callback) => {
        const query = 'INSERT INTO roles (short_name, role_name, role_type) VALUES ?';
        const values = roleData.map(role => [role.short_name, role.role_name, role.role_type]);
        db.query(query, [values], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database insert error', data: err });
            }
            callback(null, results);
        });
    },
    
    updateRole: (role_id, updatedData, callback) => {
        const query = 'UPDATE roles SET ? WHERE id = ?';
        db.query(query, [updatedData, role_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },

    findRoleName: (id, callback) => {
        const query = 'SELECT * FROM roles WHERE id = ? AND role_status=1';
        db.query(query, [id], (err, results) => {
          if (err) {
            return callback(err, null);
          }
          if (results.length > 0) {
            return callback(null, results[0]);
          } else {
            return callback({ statusCode: 404, message: 'Role not found' }, null);
          }
        });
    },

    getAllMenues: (callback) => {
        const query = 'SELECT * FROM meta_menu where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getmenuById: (id, callback) => {
        const query = 'SELECT * FROM meta_menu WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    findMenu: async (menu_names) => {
        const query = 'SELECT menu_name FROM meta_menu WHERE menu_name IN (?) AND status=1';
        return new Promise((resolve, reject) => {
            db.query(query, [menu_names], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results.map(result => result.name));
            });
        });
    },

    insertMenues: (menu_names, callback) => {
        const query = 'INSERT INTO meta_menu (menu_name) VALUES ?';
        const values = menu_names.map(name => [name]);
        db.query(query, [values], callback);
    },

    updateMenu: (menu_id, updatedData, callback) => {
        const query = 'UPDATE meta_menu SET ? WHERE id = ?';
        db.query(query, [updatedData, menu_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },

    getAllSubMenues: (callback) => {
        const query = 'SELECT * FROM meta_sub_menu where status=1';
        db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, { statusCode: 200, message: 'Success', data: results });
        });
    },

    getSubMenuById: (id, callback) => {
        const query = 'SELECT * FROM meta_sub_menu WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database query error', data: err });
            }
            callback(null, results[0]);
        });
    },

    findSubMenu: async (menu_id, submenu_names) => {
        try {
          const placeholders = submenu_names.map(() => '?').join(',');
          const query = `SELECT submenu_name FROM meta_sub_menu WHERE menu_id = ? AND submenu_name IN (${placeholders})`;
          const values = [menu_id, ...submenu_names];
          const rows = await db.query(query, values);
          
          // Ensure rows is an array
          if (!Array.isArray(rows)) {
            throw new Error('Database query did not return an array');
          }
          
          // Extract submenu names from rows
          const submenuNames = rows.map(row => row.submenu_name);
    
          return submenuNames;
        } catch (err) {
          console.error('Error finding submenus:', err);
          throw err; // Propagate the error
        }
      },
    
      insertSubMenu: async (subMenuReqData) => {
        try {
          const query = `INSERT INTO meta_sub_menu (menu_id, submenu_name) VALUES (?, ?)`;
          const values = [subMenuReqData.menu_id, subMenuReqData.submenu_name];
          return await db.query(query, values);
        } catch (err) {
          console.error('Error inserting submenu:', err);
          throw err; // Propagate the error
        }
      },

    findChild: async (child_names) => {
        const query = 'SELECT child_name FROM meta_sub_menu WHERE child_name IN (?) AND status=1';
        return new Promise((resolve, reject) => {
            db.query(query, [child_names], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results.map(result => result.name));
            });
        });
    },

    insertChilds: (subId, childnames, callback) => {
        // Define the query with placeholders for multiple rows
        const query = 'INSERT INTO meta_sub_menu (submenu_id, child_name) VALUES ?';
    
        // Prepare values as an array of arrays [[name1], [name2], ...]
        const values = childnames.map(name => [subId, name]); // Assuming subId is provided
    
        // Execute the query with the prepared values
        db.query(query, [values], (err, result) => {
            if (err) {
                console.error('Error inserting child names:', err);
                callback(err, null); // Pass error to callback
                return;
            }
            callback(null, result); // Pass result to callback
        });
    },

    updateSubMenu: (sub_id, updatedData, callback) => {
        const query = 'UPDATE meta_sub_menu SET ? WHERE id = ?';
        db.query(query, [updatedData, sub_id], (err, results) => {
            if (err) {
                return callback({ statusCode: 500, message: 'Database update error', data: err });
            }
            callback(null, results);
        });
    },
    
    getdynamicMenu: (callback) => {
        const query = `
        SELECT 
    m.id AS menu_id,
    m.menu_name,
    s.id AS submenu_id,
    s.submenu_name,
    c.submenu_id AS childmenu_id,
    c.child_name
FROM meta_menu m
LEFT JOIN meta_sub_menu s ON m.id = s.menu_id
LEFT JOIN meta_sub_menu c ON s.id = c.submenu_id
ORDER BY m.id, s.id, c.submenu_id;
    `;

    db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }
        callback(null, results); // Pass results to callback
    });
},

findAccessOption: (optionname) => {
    return new Promise((resolve, reject) => {
        const query = 'SELECT * FROM access_option WHERE option_name IN (?) AND status=1';
        db.query(query, [optionname], (err, results) => {
            if (err) {
                return reject({ statusCode: 500, message: 'Database query error', data: err });
            }
            resolve(results);
        });
    });
},

insertAccessOption: (accessData, callback) => {
    const query = 'INSERT INTO access_option (option_name) VALUES ?';
    const values = accessData.map(access => [access.option_name]);
    db.query(query, [values], (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database insert error', data: err });
        }
        callback(null, results);
    });
},

getSourceData: (callback) => {
    const query = 'SELECT * FROM source_type where status=1';
    db.query(query, (err, results) => {
    if (err) {
        return callback({ statusCode: 500, message: 'Database query failed', data: err });
    }
    callback(null, { statusCode: 200, message: 'Success', data: results });
    });
},

getGlobalSourceData: (callback) => {
    const query = `
        SELECT 
            d.id AS datatype_id,
            d.dataType_name,
            s.id AS source_id,
            s.sourceType_name
        FROM data_type d
        LEFT JOIN source_type s ON d.id = s.data_type
        ORDER BY d.id, s.id;
    `;

    db.query(query, (err, results) => {
        if (err) {
            return callback({ statusCode: 500, message: 'Database query failed', data: err });
        }

        // Process results to the desired format
        const data = [];
        const dataTypeMap = {};

        results.forEach(row => {
            const { datatype_id, dataType_name, source_id, sourceType_name } = row;

            if (!dataTypeMap[datatype_id]) {
                dataTypeMap[datatype_id] = {
                    dataType_id: datatype_id,
                    dataType_name: dataType_name,
                    sourceType: []
                };
                data.push(dataTypeMap[datatype_id]);
            }

            if (source_id) {
                dataTypeMap[datatype_id].sourceType.push({
                    sourceType_id: source_id,
                    sourceType_name: sourceType_name
                });
            }
        });

        callback(null, {
            message: "Data fetched successfully",
            data: data
        });
    });
},
    
};

module.exports = Meta;
