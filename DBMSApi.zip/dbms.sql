-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2024 at 02:20 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_option`
--

CREATE TABLE `access_option` (
  `id` int(11) NOT NULL,
  `option_name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `access_option`
--

INSERT INTO `access_option` (`id`, `option_name`, `status`, `created_at`) VALUES
(1, 'Add', 1, '2024-07-04 18:25:06'),
(2, 'Edit', 1, '2024-07-04 18:25:06'),
(3, 'Delete', 1, '2024-07-04 18:25:06'),
(4, 'On/Off', 1, '2024-07-04 18:25:06'),
(5, 'Sync', 1, '2024-07-04 18:25:06'),
(6, 'Mapping', 1, '2024-07-04 18:25:06'),
(7, 'Bulk Allotment', 1, '2024-07-04 18:25:06'),
(8, 'Bulk Update', 1, '2024-07-04 18:25:06'),
(9, 'Assign Works', 1, '2024-07-04 18:25:06'),
(10, 'Add Data', 1, '2024-07-04 18:25:06'),
(11, 'Export Data', 1, '2024-07-04 18:25:06'),
(12, 'Filter By Keywords', 1, '2024-07-04 18:25:06'),
(13, 'Filter By Sources', 1, '2024-07-04 18:25:06');

-- --------------------------------------------------------

--
-- Table structure for table `add_keyword`
--

CREATE TABLE `add_keyword` (
  `id` int(11) NOT NULL,
  `keyword_name` varchar(250) NOT NULL,
  `selected_topic` varchar(50) NOT NULL,
  `data_available_from` varchar(100) NOT NULL,
  `data_available_to` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  `mapping_keywords` varchar(1000) NOT NULL,
  `selected_works` varchar(500) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` tinyint(4) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_keyword`
--

INSERT INTO `add_keyword` (`id`, `keyword_name`, `selected_topic`, `data_available_from`, `data_available_to`, `remarks`, `mapping_keywords`, `selected_works`, `status`, `created_at`) VALUES
(1, 'jayaram', 'Main Topic', '1', '1', '1', '{\"mainTopic\":[1,2,3,4,5,6],\"subTopic\":[9,3,2]}', '[1,2,5,4,3]', 0, 127),
(2, 'jayaram2', 'Main Topic', '1', '1', '1', '{\"mainTopic\":[1,2,3,4,5,6],\"subTopic\":[9,3,2]}', '[1,2,5,4,3]', 1, 127);

-- --------------------------------------------------------

--
-- Table structure for table `add_source`
--

CREATE TABLE `add_source` (
  `id` int(11) NOT NULL,
  `mapping_keywords` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `selected_works` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `source_type_id` int(11) NOT NULL,
  `source_details_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_source`
--

INSERT INTO `add_source` (`id`, `mapping_keywords`, `selected_works`, `source_type_id`, `source_details_id`, `status`, `created_at`) VALUES
(1, '{\"mainTopic\":[1,2,3,4,5],\"subTopic\":[9,43,2]}', '[1,23,543,45,43]', 1, 9, 0, '2024-07-12 18:34:54'),
(2, '{\"mainTopic\":[1,2,3,4,5,6],\"subTopic\":[9,3,2]}', '[1,2,5,4,3]', 2, 10, 0, '2024-07-12 18:37:26');

-- --------------------------------------------------------

--
-- Table structure for table `add_source_details`
--

CREATE TABLE `add_source_details` (
  `id` int(11) NOT NULL,
  `source_type_id` int(11) NOT NULL,
  `source_origin_id` int(11) NOT NULL,
  `journal_name` varchar(250) NOT NULL,
  `journal_link` varchar(250) NOT NULL,
  `journal_EISSN` varchar(100) NOT NULL,
  `conference_name` varchar(250) NOT NULL,
  `conference_dates` varchar(250) NOT NULL,
  `conference_venue` varchar(250) NOT NULL,
  `conference_PDF` varchar(1000) NOT NULL,
  `department_name` varchar(250) NOT NULL,
  `source_link` varchar(250) NOT NULL,
  `Data_available_From` varchar(250) NOT NULL,
  `Data_available_To` varchar(250) NOT NULL,
  `subjects` text NOT NULL,
  `Remarks` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_source_details`
--

INSERT INTO `add_source_details` (`id`, `source_type_id`, `source_origin_id`, `journal_name`, `journal_link`, `journal_EISSN`, `conference_name`, `conference_dates`, `conference_venue`, `conference_PDF`, `department_name`, `source_link`, `Data_available_From`, `Data_available_To`, `subjects`, `Remarks`, `status`, `created_at`) VALUES
(1, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 16:46:31'),
(2, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 17:44:20'),
(3, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 17:47:56'),
(4, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 18:21:32'),
(5, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 18:25:08'),
(6, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 18:29:59'),
(7, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 18:31:56'),
(8, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 18:32:29'),
(9, 1, 1, 'test', 'test', 'test', '', '', '', '', '', 'test', 'test', 'test', 'test', 'test', 1, '2024-07-12 18:34:54'),
(10, 2, 2, '', '', '', 'test2', 'test2', 'test2', 'test2', '', 'test2', 'test2', 'test2', 'test2', 'test2', 1, '2024-07-12 18:37:26');

-- --------------------------------------------------------

--
-- Table structure for table `bulk_keyword_upload`
--

CREATE TABLE `bulk_keyword_upload` (
  `id` int(11) NOT NULL,
  `mapped_name` varchar(250) NOT NULL,
  `topic_type` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bulk_keyword_upload`
--

INSERT INTO `bulk_keyword_upload` (`id`, `mapped_name`, `topic_type`, `status`, `created_at`) VALUES
(1, 'Earth Secience', 'Main Topics', 1, '2024-07-15 12:39:00'),
(2, 'Agriculture', 'Sub Topics', 1, '2024-07-15 12:39:00'),
(3, '2 Material', 'Sub Topics', 1, '2024-07-15 12:39:00'),
(4, 'Agriculture', 'Main Topics', 1, '2024-07-15 12:39:44');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_url` varchar(100) NOT NULL,
  `post_panel_url` varchar(1000) NOT NULL,
  `cms_url` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `company_name`, `company_url`, `post_panel_url`, `cms_url`, `description`, `status`, `created_at`) VALUES
(1, 'jaya', '123456', '[\"test\",\"test1\"]', 'jai4@gmail.com', 'vayala', 1, '2024-07-08 15:22:02');

-- --------------------------------------------------------

--
-- Table structure for table `data_source`
--

CREATE TABLE `data_source` (
  `id` int(11) NOT NULL,
  `source_data_name` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_source`
--

INSERT INTO `data_source` (`id`, `source_data_name`, `status`, `created_at`) VALUES
(1, 'pmc', 1, '2024-07-13 14:34:54'),
(2, 'epmc', 1, '2024-07-13 14:34:54'),
(3, 'pubmed', 1, '2024-07-13 14:34:54');

-- --------------------------------------------------------

--
-- Table structure for table `data_type`
--

CREATE TABLE `data_type` (
  `id` int(11) NOT NULL,
  `dataType_name` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_type`
--

INSERT INTO `data_type` (`id`, `dataType_name`, `status`, `created_at`) VALUES
(1, 'Keywords', 1, '2024-07-10 16:33:00'),
(2, 'All Sources', 1, '2024-07-10 16:33:00');

-- --------------------------------------------------------

--
-- Table structure for table `filter_data_set`
--

CREATE TABLE `filter_data_set` (
  `id` int(11) NOT NULL,
  `dataset_name` varchar(500) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `filter_data_set`
--

INSERT INTO `filter_data_set` (`id`, `dataset_name`, `description`, `status`, `created_at`) VALUES
(1, 'test', 'Univeristy of South Florida', 1, '2024-07-15 09:39:08');

-- --------------------------------------------------------

--
-- Table structure for table `filter_data_set_rules`
--

CREATE TABLE `filter_data_set_rules` (
  `id` int(11) NOT NULL,
  `filter_rule_name` varchar(250) NOT NULL,
  `data_set_id` int(11) NOT NULL,
  `selected_works` varchar(500) NOT NULL,
  `data_type_id` int(11) NOT NULL,
  `blacklist_whitelist` varchar(250) NOT NULL,
  `filter` varchar(250) NOT NULL,
  `description` tinytext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `filter_data_set_rules`
--

INSERT INTO `filter_data_set_rules` (`id`, `filter_rule_name`, `data_set_id`, `selected_works`, `data_type_id`, `blacklist_whitelist`, `filter`, `description`, `status`, `created_at`) VALUES
(1, 'testing', 1, '[1,23,543,45,43]', 2, 'remove', 'while downloading', 'test', 1, '2024-07-15 16:58:12');

-- --------------------------------------------------------

--
-- Table structure for table `mapping_keywords`
--

CREATE TABLE `mapping_keywords` (
  `id` int(11) NOT NULL,
  `main_topics` varchar(250) NOT NULL,
  `sub_topics` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `meta_menu`
--

CREATE TABLE `meta_menu` (
  `id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meta_menu`
--

INSERT INTO `meta_menu` (`id`, `menu_name`, `status`, `created_at`) VALUES
(1, 'Dashboard', 1, '2024-07-04 11:29:00'),
(2, 'Companies', 1, '2024-07-04 11:29:00'),
(3, 'Works', 1, '2024-07-04 11:29:00'),
(4, 'Keywords', 1, '2024-07-04 11:29:00'),
(5, 'Sources', 1, '2024-07-04 11:29:00'),
(6, 'Query Controls', 1, '2024-07-04 11:29:00'),
(7, 'Task Management', 1, '2024-07-04 11:29:00'),
(8, 'Bulk Task Allotment', 1, '2024-07-04 11:29:00'),
(9, 'Quality Control', 1, '2024-07-04 11:29:00'),
(10, 'Download Controls', 1, '2024-07-04 11:29:00'),
(11, 'DBMS Search Engine', 1, '2024-07-04 11:29:00'),
(12, 'Super Admin', 1, '2024-07-04 11:29:00');

-- --------------------------------------------------------

--
-- Table structure for table `meta_sub_menu`
--

CREATE TABLE `meta_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `submenu_name` varchar(100) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  `child_name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meta_sub_menu`
--

INSERT INTO `meta_sub_menu` (`id`, `menu_id`, `submenu_name`, `submenu_id`, `child_name`, `status`, `created_at`) VALUES
(1, 4, 'Keyword Search', 0, '', 1, '2024-07-04 15:04:34'),
(2, 4, 'Add Keyword', 0, '', 1, '2024-07-04 15:04:34'),
(3, 4, 'All Keywords', 0, '', 1, '2024-07-04 15:04:34'),
(4, 5, 'Source Search', 0, '', 1, '2024-07-04 15:04:34'),
(5, 5, 'Add Source', 0, '', 1, '2024-07-04 15:04:34'),
(6, 5, 'All Sources', 0, '', 1, '2024-07-04 15:04:34'),
(7, 5, 'Sources Origin', 0, '', 1, '2024-07-04 15:04:34'),
(8, 5, 'Conference Documents', 0, '', 1, '2024-07-04 15:04:34'),
(9, 6, 'Data Approval Center', 0, '', 1, '2024-07-04 15:04:34'),
(10, 6, 'Keyword Approval Center', 0, '', 1, '2024-07-04 15:04:34'),
(11, 6, 'Source Approval Center', 0, '', 1, '2024-07-04 15:04:34'),
(12, 10, 'Download Filters', 0, '', 1, '2024-07-04 15:04:34'),
(13, 10, 'Download Limits', 0, '', 1, '2024-07-04 15:04:34'),
(14, 12, 'User Accounts', 0, '', 1, '2024-07-04 15:04:34'),
(15, 12, 'User Reports', 0, '', 1, '2024-07-04 15:04:34'),
(16, 12, 'Cluster In Process Datasets', 0, '', 1, '2024-07-04 15:04:34'),
(17, 12, 'Panel Control', 0, '', 1, '2024-07-04 15:04:34'),
(18, 12, 'Panel Logs', 0, '', 1, '2024-07-04 15:04:34'),
(19, 0, '', 12, 'Filter Data Sets', 1, '2024-07-04 15:51:24'),
(20, 0, '', 12, 'Filter Rules', 1, '2024-07-04 15:51:24');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `short_name` varchar(25) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `role_type` varchar(50) NOT NULL,
  `role_status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `short_name`, `role_name`, `role_type`, `role_status`, `created_at`) VALUES
(1, 'SA', 'Super Admin', 'super_admin', 1, '2024-07-03 14:47:07'),
(2, 'M', 'Manager', 'manager', 1, '2024-07-03 14:47:07'),
(3, 'TL', 'Team Lead', 'team_lead', 1, '2024-07-03 14:47:07'),
(4, 'TM', 'Team Member', 'team_member', 1, '2024-07-03 14:47:07'),
(5, 'THP', 'Team Handling Person', 'team_handling_person', 1, '2024-07-03 14:47:07'),
(6, 'QC', 'Quality Control', 'quality_control', 1, '2024-07-03 14:47:07');

-- --------------------------------------------------------

--
-- Table structure for table `role_access`
--

CREATE TABLE `role_access` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  `access_option_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `source_origin`
--

CREATE TABLE `source_origin` (
  `id` int(11) NOT NULL,
  `source_type_id` int(11) NOT NULL,
  `source_origin_name` varchar(250) NOT NULL,
  `source_origin_url` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `source_origin`
--

INSERT INTO `source_origin` (`id`, `source_type_id`, `source_origin_name`, `source_origin_url`, `status`, `created_at`) VALUES
(1, 3, 'Univeristy of South Florida', 'https://www.usf.edu.in', 1, '2024-07-10 18:37:12'),
(2, 2, 'Magnus Group Conferences', 'https://www.magnusgroup.org', 1, '2024-07-10 18:38:15'),
(3, 3, 'Univeristy of South Florida', 'https://www.usf.edu.in', 1, '2024-07-10 18:38:43');

-- --------------------------------------------------------

--
-- Table structure for table `source_type`
--

CREATE TABLE `source_type` (
  `id` int(11) NOT NULL,
  `data_type` int(11) NOT NULL,
  `sourceType_name` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `source_type`
--

INSERT INTO `source_type` (`id`, `data_type`, `sourceType_name`, `status`, `created_at`) VALUES
(1, 2, 'Archives', 1, '2024-07-10 16:35:03'),
(2, 2, 'Universities', 1, '2024-07-10 16:35:03'),
(3, 2, 'Conferences', 1, '2024-07-10 16:35:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_type` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `user_name`, `password`, `role_type`, `status`, `created_at`) VALUES
(1, 'jayaram vayala', 'jayaram_v@magnusgroup.co.in', '$2b$10$NjOkZEKqVHNAJ/GCjxOSvOn2kyTsIm4O3bt3v6wRR5ZkqwjBVi0lW', 1, 1, '2024-07-05 12:25:42'),
(2, 'ranjith_g', 'ranjith_g@magnusgroup.co.in', '$2b$10$Iy.NaOJbOZVjaWIatVA.y.1uv5gnFFdbimPCSJGpM3QS4hecUllRG', 1, 1, '2024-07-05 12:45:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `log_type` varchar(250) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`id`, `user_id`, `ip_address`, `log_type`, `created_at`) VALUES
(1, 1, '192.168.1.63', 'Log In', '2024-07-05 14:51:18'),
(2, 1, '192.168.1.63', 'Log Out', '2024-07-05 14:51:40'),
(3, 2, '192.168.1.63', 'Log Out', '2024-07-05 15:10:55'),
(4, 1, '192.168.1.63', 'Log Out', '2024-07-05 15:30:38');

-- --------------------------------------------------------

--
-- Table structure for table `works`
--

CREATE TABLE `works` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `short_name` varchar(100) NOT NULL,
  `company_id` int(11) NOT NULL,
  `manager_id` int(11) NOT NULL,
  `team_lead_id` int(11) NOT NULL,
  `team_member_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `works`
--

INSERT INTO `works` (`id`, `full_name`, `short_name`, `company_id`, `manager_id`, `team_lead_id`, `team_member_id`, `status`, `created_at`) VALUES
(1, 'jayaram vayala', 'jk.com', 1, 1, 1, 1, 1, '2024-07-09 12:33:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_option`
--
ALTER TABLE `access_option`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_keyword`
--
ALTER TABLE `add_keyword`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_source`
--
ALTER TABLE `add_source`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_source_details`
--
ALTER TABLE `add_source_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bulk_keyword_upload`
--
ALTER TABLE `bulk_keyword_upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_source`
--
ALTER TABLE `data_source`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_type`
--
ALTER TABLE `data_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filter_data_set`
--
ALTER TABLE `filter_data_set`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filter_data_set_rules`
--
ALTER TABLE `filter_data_set_rules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mapping_keywords`
--
ALTER TABLE `mapping_keywords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meta_menu`
--
ALTER TABLE `meta_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meta_sub_menu`
--
ALTER TABLE `meta_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_access`
--
ALTER TABLE `role_access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `source_origin`
--
ALTER TABLE `source_origin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `source_type`
--
ALTER TABLE `source_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `works`
--
ALTER TABLE `works`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_option`
--
ALTER TABLE `access_option`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `add_keyword`
--
ALTER TABLE `add_keyword`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `add_source`
--
ALTER TABLE `add_source`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `add_source_details`
--
ALTER TABLE `add_source_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `bulk_keyword_upload`
--
ALTER TABLE `bulk_keyword_upload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data_source`
--
ALTER TABLE `data_source`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `data_type`
--
ALTER TABLE `data_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `filter_data_set`
--
ALTER TABLE `filter_data_set`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `filter_data_set_rules`
--
ALTER TABLE `filter_data_set_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mapping_keywords`
--
ALTER TABLE `mapping_keywords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `meta_menu`
--
ALTER TABLE `meta_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `meta_sub_menu`
--
ALTER TABLE `meta_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `role_access`
--
ALTER TABLE `role_access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `source_origin`
--
ALTER TABLE `source_origin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `source_type`
--
ALTER TABLE `source_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `works`
--
ALTER TABLE `works`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
