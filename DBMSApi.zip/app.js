const express = require('express');
const app = express();
const cors = require('cors');
const authRoutes = require('./routes/authRoutes');
const metaDataRoutes = require('./routes/metaDataRoutes');
const companiesRoutes = require('./routes/companiesRoutes');
const worksRoutes = require('./routes/worksRoutes');
const sourceRoutes = require('./routes/sourceRoutes');
const keywordRoutes = require('./routes/keywordRoutes');
const filterRoutes = require('./routes/filterRoutes');
const validationRoutes = require('./routes/validateEmailRoutes');
require('dotenv').config();

const corsOptions = {
  origin: 'http://localhost:4200', // Update with your Angular app's URL
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
};
// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors(corsOptions));

app.set('view engine', 'ejs');

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/meta', metaDataRoutes);
app.use('/api/companies', companiesRoutes);
app.use('/api/works', worksRoutes);
app.use('/api/source', sourceRoutes);
app.use('/api/keyword', keywordRoutes);
app.use('/api/filter', filterRoutes);
app.use('/api/uploadEmails', validationRoutes);

app.get('/', (req, res) => {
  res.render('index');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
