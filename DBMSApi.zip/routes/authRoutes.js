const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const verifyToken = require('../middleware/jwtMiddleware');

router.get('/users-list/:id?', authController.getUserData);
router.post('/login/', authController.login);
router.post('/add-user/', authController.register);
router.post('/set-logs/', verifyToken , authController.setLoginLogs);
router.get('/get-logs/:id?', verifyToken , authController.getLoginLogs);
router.post('/profile/', verifyToken , authController.getProfile);
router.post('/update-profile/', verifyToken , authController.updateProfile);
router.post('/update-password/', verifyToken , authController.updatePassword);

module.exports = router;
