const express = require('express');
const router = express.Router();
const sourceController = require('../controllers/sourceController');

router.get('/origin/:id?', sourceController.getOriginData);
router.post('/add/origin', sourceController.insertOrigin);
router.put('/update/origin', sourceController.updateOrigin);
router.get('/getsource/:id?', sourceController.getSourceData);
router.post('/add/source', sourceController.insertSource);
router.put('/update/source', sourceController.updateSource);

module.exports = router;
