const express = require('express');
const router = express.Router();
const worksController = require('../controllers/worksController');

router.get('/info/:id?', worksController.getAllWorks);
router.post('/add/info', worksController.insertWorks);
router.put('/update/info', worksController.updateWorks);

module.exports = router;
