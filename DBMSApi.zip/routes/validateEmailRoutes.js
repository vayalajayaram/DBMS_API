const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const emailController = require('../controllers/validateController');

// Set up multer for file uploads
const upload = multer({ dest: path.join(__dirname, '../uploads/') });

router.post('/upload', upload.single('file'), emailController.uploadFile);

// Serve the download links
router.get('/downloads/:file', (req, res) => {
    const file = req.params.file;
    const filePath = path.join(__dirname, '../uploads/', file);
    res.download(filePath);
  });

module.exports = router;
