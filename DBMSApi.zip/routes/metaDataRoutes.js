const express = require('express');
const router = express.Router();
const metaController = require('../controllers/metaDataController');

//role meta
router.get('/role/:id?', metaController.getAllRoles);
router.post('/addrole', metaController.insertRoles);
router.put('/updaterole', metaController.updateRole);
router.post('/addaccessoption', metaController.insertAccessOption);

//menu meta
router.get('/getmenu/:id?', metaController.getAllMenu);
router.post('/menu', metaController.insertMenu);
router.put('/updatemenu', metaController.updateMenu);
router.get('/getsubmenu/:id?', metaController.getAllSubmenu);
router.post('/submenus', metaController.insertSubMenu);
router.post('/subchild', metaController.insertSubChild);
router.put('/updatesubmenu', metaController.updateSubMenu);
router.get('/getmenulist', metaController.getDynamicMenu);
router.get('/globalsourcedata/:data?', metaController.getGlobalSource);

module.exports = router;
