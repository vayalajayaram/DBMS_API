const express = require('express');
const router = express.Router();
const companiesController = require('../controllers/companiesController');

router.get('/info/:id?', companiesController.getAllCompanies);
router.post('/add/info', companiesController.insertCompanies);
router.put('/update/info', companiesController.updateCompanies);

module.exports = router;
