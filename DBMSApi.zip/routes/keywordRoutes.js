const express = require('express');
const router = express.Router();
const keywordController = require('../controllers/keywordController');

router.get('/fetch/:id?', keywordController.getAllKeywords);
router.post('/add/data', keywordController.insertKeyword);
router.put('/update/data', keywordController.updateKeyword);
router.post('/bulk/upload', keywordController.bulkUploadKeywords);

module.exports = router;
