const express = require('express');
const router = express.Router();
const filterController = require('../controllers/filterController');

router.get('/dataset/:id?', filterController.getDataSet);
router.post('/add/dataset', filterController.insertDataSet);
router.put('/update/dataset', filterController.updateDataSet);
router.get('/getdatasetrules/:id?', filterController.getDataSetRules);
router.post('/add/datasetrules', filterController.insertSetRules);
router.put('/update/datasetrule', filterController.updateSetRules);

module.exports = router;
