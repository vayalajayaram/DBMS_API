const Meta = require('../models/metaDataModel');

const metaDataController = {
    getAllRoles: (req, res, next) => {
        const { id } = req.params;
      
            if (id) {
                Meta.findRoleName(id, (err, role) => {
                    if (err) {
                      const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                      return res.status(statusCode).send({ message, data });
                    }
                    const statusCode = 200;
                    const message = 'role fetched successfully';
                    const data = role;
                    res.status(statusCode).send({ message, data });
                  });
            } else {

                Meta.getAllRoles((err, roles) => {
                    if (err) {
                      const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                      return res.status(statusCode).send({ message, data });
                    }
                    const statusCode = 200;
                    const message = 'roles fetched successfully';
                    const data = roles;
                    res.status(statusCode).send({ message, data });
                });
            }
    },

    insertRoles: async (req, res, next) => {
        const { short_name, role_name, role_type } = req.body;
    
        if (!Array.isArray(short_name) || !Array.isArray(role_name) || !Array.isArray(role_type)) {
            return res.status(400).send({ message: 'Invalid input. short_name, role_name, and role_type must be arrays.', data: null });
        }
    
        if (short_name.length !== role_name.length || role_type.length !== role_name.length) {
            return res.status(400).send({ message: 'short_name, role_name, and role_type count must be equal.', data: null });
        }
    
        try {
            // Check for existing roles
            const existingRoles = await Meta.findRoles(short_name, role_name, role_type);
    
            const roleData = short_name.map((name, index) => ({
                short_name: name,
                role_name: role_name[index],
                role_type: role_type[index]
            })).filter(roleObj => {
                return !existingRoles.some(existingRole => 
                    existingRole.role === roleObj.role || existingRole.role_name === roleObj.role_name
                );
            });
    
            if (roleData.length === 0) {
                return res.status(409).send({ message: 'All roles already exist.', data: null });
            }
    
            await Meta.insertRoles(roleData);
            return res.status(201).send({ message: 'Roles inserted successfully', data: roleData });
        } catch (err) {
            console.error(err);
            return res.status(500).send({ message: 'Internal Server Error', data: null });
        }
    },

    updateRole: (req, res, next) => {
        const { role_id, short_name, role_name, role_type, role_status } = req.body;

        if (!role_id) {
            return res.status(400).send({ message: 'Invalid input. "role_id" is required.', data: null });
        }

        const updatedData = {};
        if (short_name) updatedData.short_name = short_name;
        if (role_name) updatedData.role_name = role_name;
        if (role_type) updatedData.role_type = role_type;
        if (role_status !== undefined) updatedData.role_status = role_status;
        
        if (Object.keys(updatedData).length === 0) {
            return res.status(400).send({ message: 'Invalid input. "short_name" or "role_name" or "role_type" or "role_status" must be provided.', data: null });
        }

        Meta.updateRole(role_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Role not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Role updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

    findRoleName: (req, res, next) => {
        const roleId = parseInt(req.params.id, 10);
        Meta.findRoleName(roleId, (err, role) => {
          if (err) {
            const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
            return res.status(statusCode).send({ message, data });
          }
          const statusCode = 200;
          const message = 'role fetched successfully';
          const data = role;
          res.status(statusCode).send({ message, data });
        });
    },

    getAllMenu :(req, res, next) => {
            const { id } = req.params;
      
            if (id) {
                Meta.getmenuById(id, (err, user) => {
                    if (err) {
                        const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                        return res.status(statusCode).send({ message, data });
                    }
      
                    if (!user) {
                        return res.status(404).send({ message: 'Menu not found.', data: null });
                    }
      
                    const statusCode = 200;
                    const message = 'Menu fetched successfully';
                    const data = user;
                    res.status(statusCode).send({ message, data });
                });
            } else {
              
                Meta.getAllMenues((err , cats) => {
                    if (err) {
                        const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                        return res.status(statusCode).send({ message, data });
                    }
                    const statusCode = 200;
                    const message = 'menus fetched successfully';
                    const data = cats;
                    res.status(statusCode).send({ message, data });
                });
            }
    },

    insertMenu: async (req, res, next) => {
        const { menu_name } = req.body;
        
        if (!menu_name || !Array.isArray(menu_name)) {
            return res.status(400).send({ message: 'Invalid input. "menu_name" must be arrays.', data: null });
        }

        try {
            const existingMenues = await Meta.findMenu(menu_name);
    
            if (existingMenues.length === menu_name.length) {
                return res.status(409).send({ message: 'All menues already exist.', data: null });
            }
    
            // Filter out existing menu from the input array
            const newMenus= menu_name.filter(menu => !existingMenues.includes(menu));
    
            Meta.insertMenues(newMenus, (err, result) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
                const statusCode = 201;
                const message = 'Menues inserted successfully';
                const data = result;
                res.status(statusCode).send({ message, data });
            });
        } catch (err) {
            const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
            return res.status(statusCode).send({ message, data });
        }
    },

    updateMenu: (req, res, next) => {
        const { id, menu_name, status } = req.body;

        if (!id) {
            return res.status(400).send({ message: 'Invalid input. "id" is required.', data: null });
        }

        const updatedData = {};
        if (menu_name) updatedData.menu_name = menu_name;
        if (status !== undefined) updatedData.status = status;
        
        if (Object.keys(updatedData).length === 0) {
            return res.status(400).send({ message: 'Invalid input. "menu_name" or "status" must be provided.', data: null });
        }

        Meta.updateMenu(id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Menu not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Menu updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

        insertMenu: async (req, res, next) => {
        const { menu_name } = req.body;
        
        if (!menu_name || !Array.isArray(menu_name)) {
            return res.status(400).send({ message: 'Invalid input. "menu_name" must be arrays.', data: null });
        }

        try {
            const existingMenues = await Meta.findMenu(menu_name);
    
            if (existingMenues.length === menu_name.length) {
                return res.status(409).send({ message: 'All menues already exist.', data: null });
            }
    
            // Filter out existing menu from the input array
            const newMenus= menu_name.filter(menu => !existingMenues.includes(menu));
    
            Meta.insertMenues(newMenus, (err, result) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
                const statusCode = 201;
                const message = 'Menues inserted successfully';
                const data = result;
                res.status(statusCode).send({ message, data });
            });
        } catch (err) {
            const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
            return res.status(statusCode).send({ message, data });
        }
    },

    getAllSubmenu :(req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            Meta.getSubMenuById(id, (err, user) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!user) {
                    return res.status(404).send({ message: 'Sub menu not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'Sub Menu fetched successfully';
                const data = user;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            Meta.getAllSubMenues((err , cats) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                  }
                  const statusCode = 200;
                  const message = 'sub menus fetched successfully';
                  const data = cats;
                  res.status(statusCode).send({ message, data });
            });
        }
    },

    insertSubMenu: async (req, res, next) => {
            const { data } = req.body;

        if (!Array.isArray(data) || data.length === 0) {
            return res.status(400).send({ message: 'Data should be a non-empty array', data: null });
        }

        try {
            for (const item of data) {
            const { menu_id, submenu_name } = item;

            if (!menu_id || !Array.isArray(submenu_name) || submenu_name.length === 0) {
                return res.status(400).send({ message: 'menu_id and submenu_name are required fields and should be non-empty arrays', data: null });
            }

            // Check for existing submenus
            //   let existingSubmenu;
            //   try {
            //     existingSubmenu = await Meta.findSubMenu(menu_id, submenu_name);
            //   } catch (err) {
            //     console.error('Error finding existing submenus:', err);
            //     return res.status(500).send({ message: 'Internal Server Error', data: err.message });
            //   }

            //   // Ensure existingSubmenu is an array of strings
            //   if (!Array.isArray(existingSubmenu)) {
            //     console.error('Unexpected result from findSubMenu:', existingSubmenu);
            //     return res.status(500).send({ message: 'Internal Server Error', data: 'Unexpected result from database' });
            //   }

            //   // Filter out existing subcategories
            //   const newSubMenuNames = submenu_name.filter(subMenu => !existingSubmenu.includes(subMenu));

            //   if (newSubMenuNames.length === 0) {
            //     return res.status(409).send({ message: 'All submenus with this menu_id already exist.', data: null });
            //   }

            // Insert submenu information
            for (const subMenu of submenu_name) {
                const subMenuReqData = {
                menu_id,
                submenu_name: subMenu
                };
                await Meta.insertSubMenu(subMenuReqData);
            }
            }

            res.status(201).send({ message: 'Data inserted successfully', data: null });
        } catch (err) {
            console.error('Error inserting submenus:', err);
            res.status(500).send({ message: 'Internal Server Error', data: err.message });
        }
    },    

    insertSubChild: async (req, res, next) => {
        const { submenu_id, child_name } = req.body;
        
        if (!submenu_id || !child_name || !Array.isArray(child_name)) {
            return res.status(400).send({ message: 'Invalid input. "child_name" must be arrays.', data: null });
        }

        try {
            const existingChilds = await Meta.findChild(child_name);

            if (existingChilds.length === child_name.length) {
                return res.status(409).send({ message: 'All Child already exist.', data: null });
            }

            // Filter out existing menu from the input array
            const newChilds= child_name.filter(child => !existingChilds.includes(child));

            Meta.insertChilds(submenu_id,newChilds, (err, result) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
                const statusCode = 201;
                const message = 'Sub Child inserted successfully';
                const data = result;
                res.status(statusCode).send({ message, data });
            });
        } catch (err) {
            const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
            return res.status(statusCode).send({ message, data });
        }
    },

    updateSubMenu: (req, res, next) => {
        const { id, menu_id, submenu_name, submenu_id, child_name, status } = req.body;

        if (!id) {
            return res.status(400).send({ message: 'Invalid input. "id" is required.', data: null });
        }

        const updatedData = {};
        if (menu_id !== undefined) updatedData.menu_id = menu_id;
        if (submenu_name !== undefined) updatedData.submenu_name = submenu_name;
        if (submenu_id !== undefined) updatedData.submenu_id = submenu_id;
        if (child_name !== undefined) updatedData.child_name = child_name;
        if (status !== undefined) updatedData.status = status;
        
        // if (Object.keys(updatedData).length === 0) {
        //     return res.status(400).send({ message: 'Invalid input. "sub_name" or "cat_id" must be provided.', data: null });
        // }

        Meta.updateSubMenu(id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Sub Menu not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Sub Menu updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

    getDynamicMenu: (req, res, next) => {
        Meta.getdynamicMenu((err, results) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }
    
            const menuMap = new Map();
    
            results.forEach(row => {
                if (!menuMap.has(row.menu_id)) {
                    menuMap.set(row.menu_id, {
                        menu_id: row.menu_id,
                        menu_name: row.menu_name,
                        submenus: []
                    });
                }
    
                const menu = menuMap.get(row.menu_id);
    
                if (row.submenu_id) {
                    let submenu = menu.submenus.find(sm => sm.submenu_id === row.submenu_id);
    
                    if (!submenu) {
                        submenu = {
                            submenu_id: row.submenu_id,
                            submenu_name: row.submenu_name,
                            childmenus: []
                        };
                        menu.submenus.push(submenu);
                    }
    
                    if (row.childmenu_id) {
                        submenu.childmenus.push({
                            childmenu_id: row.childmenu_id,
                            child_name: row.child_name
                        });
                    }
                }
            });
    
            const formattedMenus = Array.from(menuMap.values()).map(menu => ({
                menu_id: menu.menu_id,
                menu_name: menu.menu_name,
                submenus: menu.submenus.length > 0 ? menu.submenus : null
            }));
    
            const statusCode = 200;
            const message = 'menus fetched successfully';
            const data = formattedMenus;
            res.status(statusCode).send({ message, data });
        });
    },

    insertAccessOption: async (req, res, next) => {
        const { option_name } = req.body;
    
        if (!Array.isArray(option_name)) {
            return res.status(400).send({ message: 'Invalid input. option_name must be arrays.', data: null });
        }
    
        try {
            // Check for existing roles
            const existingOption = await Meta.findAccessOption(option_name);
    
            const accessData = option_name.map((name, index) => ({
                option_name: name
            })).filter(accessObj => {
                return !existingOption.some(existingOption => 
                    existingOption.option_name === accessObj.option_name
                );
            });
    
            if (accessData.length === 0) {
                return res.status(409).send({ message: 'All access option already exist.', data: null });
            }
    
            await Meta.insertAccessOption(accessData);
            return res.status(201).send({ message: 'acesss option inserted successfully', data: accessData });
        } catch (err) {
            console.error(err);
            return res.status(500).send({ message: 'Internal Server Error', data: null });
        }
    },

    getGlobalSource: (req, res, next) => {
        const { data } = req.params;
      
            if (data) {
                Meta.getSourceData((err, result) => {
                    if (err) {
                      const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                      return res.status(statusCode).send({ message, data });
                    }
                    const statusCode = 200;
                    const message = 'Data fetched successfully';
                    const data = result;
                    res.status(statusCode).send({ message, data });
                  });
            } else {

                Meta.getGlobalSourceData((err, Datas) => {
                    if (err) {
                      const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                      return res.status(statusCode).send({ message, data });
                    }
                    const statusCode = 200;
                    const message = 'Data fetched successfully';
                    const data = Datas;
                    res.status(statusCode).send({ message, data });
                });
            }
    },

};

module.exports = metaDataController;
