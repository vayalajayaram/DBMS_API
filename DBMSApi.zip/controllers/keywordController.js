const KeywordData = require('../models/keywordModel');

const keywordController = {
    getAllKeywords: (req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            KeywordData.getKeywordById(id, (err, keyword) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!keyword) {
                    return res.status(404).send({ message: 'keyword not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'Keyword fetched successfully';
                const data = keyword;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            KeywordData.getAllKeyword((err, keywords) => {
                if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
                }
                const statusCode = 200;
                const message = 'Keywords Info fetched successfully';
                const data = keywords;
                res.status(statusCode).send({ message, data });
            });
        }

    },

    insertKeyword: async (req, res, next) => {
        const { keyword_name, selected_topic, data_available_from, data_available_to, remarks, mapping_keywords, selected_works } = req.body;

        if (!keyword_name || !selected_topic || !mapping_keywords || typeof mapping_keywords !== 'object' || !Array.isArray(selected_works)) {
            return res.status(400).send({ message: 'Invalid input. Please pass required parameters.', data: null });
        }
    
        try {
            const keywordPayload = {};
            if (keyword_name !== undefined) keywordPayload.keyword_name = keyword_name;
            if (selected_topic !== undefined) keywordPayload.selected_topic = selected_topic;
            if (data_available_from !== undefined) keywordPayload.data_available_from = data_available_from;
            if (data_available_to !== undefined) keywordPayload.data_available_to = data_available_to;
            if (remarks !== undefined) keywordPayload.remarks = remarks;
            if (mapping_keywords !== undefined) keywordPayload.mapping_keywords = JSON.stringify(mapping_keywords);
            if (selected_works !== undefined) keywordPayload.selected_works = JSON.stringify(selected_works);
            
            const keywordId = await KeywordData.addKeyword(keywordPayload);
            res.status(201).json({ message: 'Keyword added successfully', keywordId });
        } catch (error) {
            res.status(500).json({ message: 'Error adding keyword details', error });
        }
    },

    updateKeyword: (req, res, next) => {
        const { keyword_id, keyword_name, selected_topic, data_available_from, data_available_to, remarks, mapping_keywords, selected_works, status } = req.body;

        if (!keyword_id) {
            return res.status(400).send({ message: 'Invalid input. "keyword_id" is required.', data: null });
        }
        const updatedData = {};
        if (keyword_name !== undefined) updatedData.keyword_name = keyword_name;
        if (selected_topic !== undefined) updatedData.selected_topic = selected_topic;
        if (data_available_from !== undefined) updatedData.data_available_from = data_available_from;
        if (data_available_to !== undefined) updatedData.data_available_to = data_available_to;
        if (remarks !== undefined) updatedData.remarks = remarks;
        if (mapping_keywords !== undefined) updatedData.mapping_keywords = JSON.stringify(mapping_keywords);
        if (selected_works !== undefined) updatedData.selected_works = JSON.stringify(selected_works);
        if (status !== undefined) updatedData.status = status;

        KeywordData.updateKeyword(keyword_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Keyword not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Keyword updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

    bulkUploadKeywords: async (req, res, next) => {
        const { bulk_upload } = req.body;

        if (!bulk_upload || !Array.isArray(bulk_upload) || bulk_upload.length === 0) {
            return res.status(400).send({ message: 'Invalid input. Please provide a valid bulk upload array.', data: null });
        }
    
        try {
            const results = [];
            for (const keyword of bulk_upload) {
                const { mapped_name, topic_type } = keyword;
    
                // Check if required fields are present
                if (!mapped_name || !topic_type) {
                    results.push({ message: 'Invalid input. Missing required fields.', data: keyword });
                    continue;
                }
    
                // Check if the keyword already exists
                const existingKeyword = await KeywordData.findKeywordDetails(mapped_name, topic_type);
    
                if (existingKeyword.length > 0) {
                    results.push({ message: `Keyword with the name '${mapped_name}' already exists.`, data: keyword });
                    continue;
                }
    
                // Insert keyword information
                const keywordReqData = { mapped_name, topic_type };
                const result = await KeywordData.insertMapKeyword(keywordReqData);  // Assuming you're using Sequelize
                results.push({ message: 'Bulk upload inserted successfully', data: result });
            }
    
            res.status(207).send({ message: 'Bulk upload process completed with the following results:', results });
        } catch (err) {
            console.error(err);
            res.status(500).send({ message: 'Internal Server Error', data: err });
        }
    },

};

module.exports = keywordController;
