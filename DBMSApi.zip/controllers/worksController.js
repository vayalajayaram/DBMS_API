const WorkData = require('../models/worksModel');

const worksController = {
    getAllWorks: (req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            WorkData.getWorkById(id, (err, company) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!company) {
                    return res.status(404).send({ message: 'work not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'Work fetched successfully';
                const data = company;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            WorkData.getAllWorks((err, companies) => {
                if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
                }
                const statusCode = 200;
                const message = 'Works Info fetched successfully';
                const data = companies;
                res.status(statusCode).send({ message, data });
            });
        }

    },

    insertWorks: async (req, res, next) => {
        const { full_name, short_name, company_id, manager_id, team_lead_id, team_member_id } = req.body;

        if (!full_name || !short_name || !company_id || !manager_id || !team_lead_id || !team_member_id ) {
            return res.status(400).send({ message: 'Invalid input. Please pass required parameters.', data: null });
        }
    
        try {
            // Check if the work already exists
            const existingWork = await WorkData.findWorkDetails(full_name);
            
            if (existingWork.length > 0) {
                return res.status(409).send({ message: `Work with the name '${full_name}' already exists.`, data: null });
            }
    
            // Insert work information
            const workReqData = { full_name, short_name, company_id, manager_id, team_lead_id, team_member_id };
            const result = await WorkData.insertWork(workReqData);
    
            res.status(201).send({ message: 'Work inserted successfully', data: result });
        } catch (err) {
            console.error(err);
            res.status(500).send({ message: 'Internal Server Error', data: err });
        }
    },

    updateWorks: (req, res, next) => {
        const { work_id, full_name, short_name, company_id, manager_id, team_lead_id, team_member_id, status } = req.body;

        if (!work_id) {
            return res.status(400).send({ message: 'Invalid input. "work_id" is required.', data: null });
        }
        const updatedData = {};
        if (full_name !== undefined) updatedData.full_name = full_name;
        if (short_name !== undefined) updatedData.short_name = short_name;
        if (company_id !== undefined) updatedData.company_id = company_id;
        if (manager_id !== undefined) updatedData.manager_id = manager_id;
        if (team_lead_id !== undefined) updatedData.team_lead_id = team_lead_id;
        if (team_member_id !== undefined) updatedData.team_member_id = team_member_id;
        if (status !== undefined) updatedData.status = status;

        WorkData.updateWork(work_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Work not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Work updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

};

module.exports = worksController;
