const filterData = require('../models/filterModel');

const filterController = {
    getDataSet: (req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            filterData.getDataSetById(id, (err, dataset) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!dataset) {
                    return res.status(404).send({ message: 'Data Set not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'Filter Data Set fetched successfully';
                const data = dataset;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            filterData.getAllDataSet((err, dataset) => {
                if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
                }
                const statusCode = 200;
                const message = 'Filter Data Set fetched successfully';
                const data = dataset;
                res.status(statusCode).send({ message, data });
            });
        }

    },

    insertDataSet: async (req, res, next) => {
        const { dataset_name, description } = req.body;

        if (!dataset_name || !description ) {
            return res.status(400).send({ message: 'Invalid input. Please pass required parameters.', data: null });
        }
    
        try {
            // Check if the data set already exists
            const existingDataset = await filterData.findDatasetDetails(dataset_name);
            
            if (existingDataset.length > 0) {
                return res.status(409).send({ message: `Data Set with the name '${dataset_name}' already exists.`, data: null });
            }
    
            // Insert data set information
            const datasetReqData = { dataset_name, description };
            const result = await filterData.insertDataset(datasetReqData);
    
            res.status(201).send({ message: 'Data set inserted successfully', data: result });
        } catch (err) {
            console.error(err);
            res.status(500).send({ message: 'Internal Server Error', data: err });
        }
    },

    updateDataSet: (req, res, next) => {
        const { dataset_id, dataset_name, description, status } = req.body;

        if (!dataset_id) {
            return res.status(400).send({ message: 'Invalid input. "dataset_id" is required.', data: null });
        }
        const updatedData = {};
        if (dataset_name !== undefined) updatedData.dataset_name = dataset_name;
        if (description !== undefined) updatedData.description = description;
        if (status !== undefined) updatedData.status = status;

        filterData.updateDataSet(dataset_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Data set not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Data Set updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },
//----------------------//------------------//
getDataSetRules: (req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            filterData.getSetRulesById(id, (err, rules) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!rules) {
                    return res.status(404).send({ message: 'Set Rules not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'Filter Set Rules fetched successfully';
                const data = rules;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            filterData.getAllSetRules((err, rules) => {
                if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
                }
                const statusCode = 200;
                const message = 'Set Rules fetched successfully';
                const data = rules;
                res.status(statusCode).send({ message, data });
            });
        }

    },

    insertSetRules: async (req, res, next) => {
        const { filter_rule_name, data_set_id, data_type_id, selected_works, blacklist_whitelist, filter, description } = req.body;

        if (!filter_rule_name || !data_set_id || !data_type_id || !blacklist_whitelist || !filter || !Array.isArray(selected_works)) {
            return res.status(400).send({ message: 'Invalid input. Please pass required parameters.', data: null });
        }
    
        try {
            const setRulePayload = {};
            if (filter_rule_name !== undefined) setRulePayload.filter_rule_name = filter_rule_name;
            if (data_set_id !== undefined) setRulePayload.data_set_id = data_set_id;
            if (data_type_id !== undefined) setRulePayload.data_type_id = data_type_id;
            if (blacklist_whitelist !== undefined) setRulePayload.blacklist_whitelist = blacklist_whitelist;
            if (filter !== undefined) setRulePayload.filter = filter;
            if (description !== undefined) setRulePayload.description = description;
            if (selected_works !== undefined) setRulePayload.selected_works = JSON.stringify(selected_works);
            
            const setruleId = await filterData.addSetRules(setRulePayload);
            res.status(201).json({ message: 'Filter Set Rules added successfully', setruleId });
        } catch (error) {
            res.status(500).json({ message: 'Error adding source details', error });
        }
    },

    updateSetRules: (req, res, next) => {
        const { datasetrule_id, filter_rule_name, data_set_id, data_type_id, selected_works, blacklist_whitelist, filter, description, status } = req.body;

        if (!datasetrule_id) {
            return res.status(400).send({ message: 'Invalid input. "datasetrule_id" is required.', data: null });
        }
        const updatedData = {};
        if (filter_rule_name !== undefined) updatedData.filter_rule_name = filter_rule_name;
        if (data_set_id !== undefined) updatedData.data_set_id = data_set_id;
        if (data_type_id !== undefined) updatedData.data_type_id = data_type_id;
        if (blacklist_whitelist !== undefined) updatedData.blacklist_whitelist = blacklist_whitelist;
        if (filter !== undefined) updatedData.filter = filter;
        if (description !== undefined) updatedData.description = description;
        if (selected_works !== undefined) updatedData.selected_works = JSON.stringify(selected_works);
        if (status !== undefined) updatedData.status = status;

        filterData.updatesetRules(datasetrule_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Origin not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Filter Data Set Rules updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

};

module.exports = filterController;
