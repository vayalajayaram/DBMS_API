const xlsx = require('xlsx');
const validator = require('validator');
const fs = require('fs');
const path = require('path');
const disposableEmailDomains = require('disposable-email-domains');

const commonEmailProviders = [
    'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com', 'icloud.com'
    // Add more common email providers as needed
  ];

exports.uploadFile = (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  const filePath = req.file.path;
  const workbook = xlsx.readFile(filePath);
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const jsonData = xlsx.utils.sheet_to_json(worksheet);

  // Regular expression to detect numbers in the domain part
  const domainWithNumbers = /[0-9]/;

  // Filter and classify emails
  const validEmails = [];
  const invalidEmails = [];
  const disposableEmails = [];
  const disposableNumbers = [];
  const corporateEmails = [];

  jsonData.forEach(row => {
    const email = row.email;
    if (email) {
      if (validator.isEmail(email)) {
        const domain = email.split('@')[1];
        if (disposableEmailDomains.includes(domain)) {
          disposableEmails.push({ email });
        } else if (domainWithNumbers.test(domain)) {
            disposableNumbers.push({ email });
        } else if (commonEmailProviders.includes(domain)) {
            validEmails.push({ email });
        } else {
            corporateEmails.push({ email });
        }
      } else {
        invalidEmails.push({ email });
      }
    } else {
      invalidEmails.push({ email: 'Invalid or missing email field' });
    }
  });

  // Create a workbook with multiple sheets
  const resultWorkbook = xlsx.utils.book_new();

  const validEmailsSheet = xlsx.utils.json_to_sheet(validEmails);
  const invalidEmailsSheet = xlsx.utils.json_to_sheet(invalidEmails);
  const disposableEmailsSheet = xlsx.utils.json_to_sheet(disposableEmails);
  const disposableNumbersSheet = xlsx.utils.json_to_sheet(disposableNumbers);
  const corporateEmailsSheet = xlsx.utils.json_to_sheet(corporateEmails);

  xlsx.utils.book_append_sheet(resultWorkbook, validEmailsSheet, 'Valid Emails');
  xlsx.utils.book_append_sheet(resultWorkbook, invalidEmailsSheet, 'Invalid Emails');
  xlsx.utils.book_append_sheet(resultWorkbook, disposableEmailsSheet, 'Disposable Emails');
  xlsx.utils.book_append_sheet(resultWorkbook, disposableNumbersSheet, 'Invalid Typo Bad');
  xlsx.utils.book_append_sheet(resultWorkbook, corporateEmailsSheet, 'Corporate Emails');

  const resultFilePath = path.join(__dirname, '../uploads/emails-result.xlsx');
  xlsx.writeFile(resultWorkbook, resultFilePath);

  res.json({ filePath: `/downloads/emails-result.xlsx` });
};
