const Auth = require('../models/authModel');
const jwt = require('jsonwebtoken'); 
const bcrypt = require('bcrypt');
const os = require('os');
const { jwtSecret, jwtExpiresIn } = require('../config/jwtConfig');

const authController = {
  getUserData: (req, res, next) => {
      const { id } = req.params;

      if (id) {
        Auth.getUserById(id, (err, getuser) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }
        
            if (!getuser) {
                return res.status(404).send({ message: 'User not found.', data: null });
            }
        
            const { password, ...sanitizedUser } = getuser;
        
            const statusCode = 200;
            const message = 'User fetched successfully';
            const data = sanitizedUser;
            res.status(statusCode).send({ message, data });
        });
      } else {
        Auth.getAllUsers((err, users) => {
              if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
              }

              const sanitizedUsers = users.map(user => {
                const { password, ...sanitizedUser } = user;
                return sanitizedUser;
            });

              const statusCode = 200;
              const message = 'Users fetched successfully';
              const data = sanitizedUsers;
              res.status(statusCode).send({ message, data });
          });
      }
  },

    register: async (req, res) => {
        try {
            const { full_name, user_name, password, role_type } = req.body;

            if (!full_name || !user_name || !password || !role_type) {
                return res.status(400).json({ message: 'All fields are required' });
            }

            // Check for existing user
            Auth.findOne({ user_name }, async (err, existingUser) => {
                if (err) {
                    return res.status(500).json({ message: 'Database error', error: err.message });
                }

                if (existingUser) {
                    return res.status(400).json({ message: 'User already exists' });
                }

                // Hash the password
                const hashedPassword = await bcrypt.hash(password, 10);

                // Create and save the new user
                const newUser = {
                  full_name,
                  user_name,
                  password: hashedPassword,
                  role_type
                };

                Auth.createUser(newUser, (err, result) => {
                    if (err) {
                        return res.status(500).json({ message: 'Database error', error: err.message });
                    }

                    // Generate a JWT
                    const token = jwt.sign({ userId: result.insertId, roleType: newUser.role_type }, jwtSecret, { expiresIn: jwtExpiresIn });

                    // Send verification email
                    // User.sendVerificationEmail(newUser.email, token);

                    res.status(201).json({ message: 'User registered successfully. Please check your email for verification.', token });
                });
            });
        } catch (error) {
            res.status(500).json({ message: 'Internal Server Error', error: error.message });
        }
    },

    login : async (req, res) => {
        const { user_name, password } = req.body;
    
        if (!user_name || !password) {
            return res.status(400).send('username and password are required');
        }
    
        Auth.findOneByUsername(user_name, (err, user) => {
            if (err) {
                return res.status(500).json({ message: 'Internal Server Error', token:null });
            }
            if (!user) {
                return res.status(400).json({ message: 'Invalid user name', token:null });
            }
    
            bcrypt.compare(password, user.password, (err, isMatch) => {
                if (err) {
                    return res.status(500).json({ message: 'Internal Server Error', token:null });
                }
                if (!isMatch) {
                    return res.status(400).json({ message: 'Invalid user name or password', token:null });
                }
    
                const token = jwt.sign({ userId: user.id, role: user.role_type }, jwtSecret, { expiresIn: jwtExpiresIn });
    
                res.status(200).json({ message: 'Login successful', token });
            });
        });
    },

    setLoginLogs : async (req, res) => {
      const { user_id, log_type } = req.body;
  
      if (!user_id || !log_type) {
          return res.status(400).send('user_id and log_type are required');
      }
        // Get the local IP address
        const interfaces = os.networkInterfaces();
        let localIpAddress = null;
        for (const name of Object.keys(interfaces)) {
            for (const net of interfaces[name]) {
                if (net.family === 'IPv4' && !net.internal) {
                    localIpAddress = net.address;
                }
            }
        }        
        if (!localIpAddress) {
            localIpAddress = 'IP address not found';
        }    
        console.log('Local IP Address:', localIpAddress);
          // Insert logs info
          const logReqData = {
            user_id,
            localIpAddress,
            log_type
          };
          try {
            const result = await Auth.insertLogInfo(logReqData);
            res.status(201).send({ message: 'Logs inserted successfully', data: result });
          } catch (error) {
              console.error('Error inserting log info:', error);
              res.status(500).send({ message: 'Internal Server Error', error: error.message });
          }
  },

  getProfile: async (req, res) => {
    const userId = req.user.userId; // retrieve the userId from the decoded JWT
    try {
        const user = await Auth.findById(userId);
        if (!user) {
            return res.status(404).send('User not found');
        }

        res.status(200).json(user);
    } catch (err) {
        res.status(500).send('Internal Server Error');
    }
},

updateProfile: async (req, res) => {
    try {
      const { username, old_password, new_password, email, fname, lname, age, role, photoUrl, contact_no, address, country, about } = req.body;
      const userId = req.user.userId;

      let hashedPassword;

      // Check if the old and new passwords are provided
      if (old_password !== undefined && new_password !== undefined) {
        const user = await Auth.findById(userId);
        if (!user) {
          return res.status(404).send('User not found');
        }

        const isMatch = await bcrypt.compare(old_password, user.password);
        if (!isMatch) {
          return res.status(400).json({ message: 'Password mismatch', token: null });
        }

        // Hash the new password
        hashedPassword = await bcrypt.hash(new_password, 10);
      }

      // Prepare the updated data objects
      const updatedData = {};
      const profileData = {};

      if (username) updatedData.username = username;
      if (new_password) updatedData.password = hashedPassword;
      if (email) updatedData.email = email;
      if (fname) updatedData.fname = fname;
      if (lname) updatedData.lname = lname;
      if (age) updatedData.age = age;
      if (role) updatedData.role = role;
      if (photoUrl) updatedData.photoUrl = photoUrl;

      if (contact_no) profileData.contact_no = contact_no;
      if (address) profileData.address = address;
      if (country) profileData.country = country;
      if (about) profileData.about = about;

      // Call the model's update method
      const result = await Auth.updateProfileData(userId, updatedData, profileData);

      if (result.affectedRows === 0) {
        return res.status(404).send({ message: 'User not found.', data: null });
      }

      res.status(200).send({ message: 'User updated successfully', data: result });
    } catch (err) {
      console.error(err);
      res.status(500).send({ message: 'Internal Server Error', data: null });
    }
  },

  updatePassword: async (req, res) => {
    try {
      const { old_password, new_password } = req.body;
      const userId = req.user.userId;
  
      if (!old_password || !new_password) {
        return res.status(400).json({ message: 'Old password and new password are required' });
      }
  
      const user = await Auth.findById(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      const isMatch = await bcrypt.compare(old_password, user.password);
      if (!isMatch) {
        return res.status(400).json({ message: 'Password mismatch' });
      }
  
      const hashedPassword = await bcrypt.hash(new_password, 10);
      const updatedData = { password: hashedPassword };
  
      Auth.updatePasswordData(userId, updatedData, (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'Internal Server Error', error: err });
        }
  
        if (result.affectedRows === 0) {
          return res.status(404).json({ message: 'User not found' });
        }
  
        res.status(200).json({ message: 'Password updated successfully', data: result });
      });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Internal Server Error', error: err });
    }
  },

  getLoginLogs: async (req, res) => {
    const { id } = req.params;
  
    try {
      if (id) {
          const log = await Auth.getLogById(id);

          if (!log) {
              return res.status(404).send({ message: 'Log not found.', data: null });
          }

          res.status(200).send({ message: 'Log fetched successfully', data: log });
      } else {
          const logs = await Auth.getAllLogs();

          res.status(200).send({ message: 'Logs fetched successfully', data: logs });
      }
  } catch (err) {
      console.error('Error fetching logs:', err);
      res.status(500).send({ message: 'Internal Server Error', data: err });
  }
},

};

module.exports = authController;
