const SourceData = require('../models/sourceModel');

const sourceController = {
    getOriginData: (req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            SourceData.getoriginById(id, (err, origin) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!origin) {
                    return res.status(404).send({ message: 'origin not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'Source Origin fetched successfully';
                const data = origin;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            SourceData.getAllOrigin((err, originies) => {
                if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
                }
                const statusCode = 200;
                const message = 'Source Origin fetched successfully';
                const data = originies;
                res.status(statusCode).send({ message, data });
            });
        }

    },

    insertOrigin: async (req, res, next) => {
        const { source_type_id, source_origin_name, source_origin_url } = req.body;

        if (!source_type_id || !source_origin_name || !source_origin_url ) {
            return res.status(400).send({ message: 'Invalid input. Please pass required parameters.', data: null });
        }
    
        try {
            // Check if the work already exists
            const existingOrigin = await SourceData.findOriginDetails(source_origin_name);
            
            if (existingOrigin.length > 0) {
                return res.status(409).send({ message: `Origin with the name '${source_origin_name}' already exists.`, data: null });
            }
    
            // Insert work information
            const originReqData = { source_type_id, source_origin_name, source_origin_url };
            const result = await SourceData.insertOrigin(originReqData);
    
            res.status(201).send({ message: 'Origin inserted successfully', data: result });
        } catch (err) {
            console.error(err);
            res.status(500).send({ message: 'Internal Server Error', data: err });
        }
    },

    updateOrigin: (req, res, next) => {
        const { origin_id, source_type_id, source_origin_name, source_origin_url, status } = req.body;

        if (!origin_id) {
            return res.status(400).send({ message: 'Invalid input. "origin_id" is required.', data: null });
        }
        const updatedData = {};
        if (source_type_id !== undefined) updatedData.source_type_id = source_type_id;
        if (source_origin_name !== undefined) updatedData.source_origin_name = source_origin_name;
        if (source_origin_url !== undefined) updatedData.source_origin_url = source_origin_url;
        if (status !== undefined) updatedData.status = status;

        SourceData.updateOrigin(origin_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Origin not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Origin updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },
//----------------------//------------------//
getSourceData: (req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            SourceData.getsourceById(id, (err, source) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!source) {
                    return res.status(404).send({ message: 'source not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'Source fetched successfully';
                const data = origin;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            SourceData.getAllSource((err, sources) => {
                if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
                }
                const statusCode = 200;
                const message = 'Sources fetched successfully';
                const data = sources;
                res.status(statusCode).send({ message, data });
            });
        }

    },

    insertSource: async (req, res, next) => {
        const { source_type_id, source_details, mapping_keywords, selected_works } = req.body;

        if (!source_type_id || !source_details || typeof source_details !== 'object' || !mapping_keywords || typeof mapping_keywords !== 'object' || !Array.isArray(selected_works)) {
            return res.status(400).send({ message: 'Invalid input. Please pass required parameters.', data: null });
        }
    
        try {
            const sourceDetailsId = await SourceData.addSourceDetails(source_type_id, source_details);
            const sourceId = await SourceData.addSource(sourceDetailsId, source_type_id, mapping_keywords, selected_works);
            res.status(201).json({ message: 'Source added successfully', sourceId });
        } catch (error) {
            res.status(500).json({ message: 'Error adding source details', error });
        }
    },

    updateSource: (req, res, next) => {
        const { origin_id, source_type_id, source_origin_name, source_origin_url, status } = req.body;

        if (!origin_id) {
            return res.status(400).send({ message: 'Invalid input. "origin_id" is required.', data: null });
        }
        const updatedData = {};
        if (source_type_id !== undefined) updatedData.source_type_id = source_type_id;
        if (source_origin_name !== undefined) updatedData.source_origin_name = source_origin_name;
        if (source_origin_url !== undefined) updatedData.source_origin_url = source_origin_url;
        if (status !== undefined) updatedData.status = status;

        SourceData.updateOrigin(origin_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Origin not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Origin updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

};

module.exports = sourceController;
