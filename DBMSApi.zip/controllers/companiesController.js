const CompanyData = require('../models/companiesModel');

const companiesController = {
    getAllCompanies: (req, res, next) => {
        const { id } = req.params;
      
        if (id) {
            CompanyData.getCompanyById(id, (err, company) => {
                if (err) {
                    const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                    return res.status(statusCode).send({ message, data });
                }
  
                if (!company) {
                    return res.status(404).send({ message: 'company not found.', data: null });
                }
  
                const statusCode = 200;
                const message = 'company fetched successfully';
                const data = company;
                res.status(statusCode).send({ message, data });
            });
        } else {
          
            CompanyData.getAllCompanies((err, companies) => {
                if (err) {
                  const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                  return res.status(statusCode).send({ message, data });
                }
                const statusCode = 200;
                const message = 'Companies Info fetched successfully';
                const data = companies;
                res.status(statusCode).send({ message, data });
            });
        }

    },

    insertCompanies: async (req, res, next) => {
        const { company_name, company_url, post_panel_url, cms_url, description } = req.body;

        if (!company_name || !company_url || !cms_url || !description || !Array.isArray(post_panel_url) || post_panel_url.length === 0 ) {
            return res.status(400).send({ message: 'Invalid input. Please pass required parameters.', data: null });
        }
    
        try {
            // Check if the vendor already exists
            const existingCompany = await CompanyData.findCompanyDetails(company_name);
            
            if (existingCompany.length > 0) {
                return res.status(409).send({ message: 'company with this name already exists.', data: null });
            }
    
            // Insert vendor information
            const companyReqData = { company_name, company_url, post_panel_url: JSON.stringify(post_panel_url), cms_url, description };
            const result = await CompanyData.insertCompany(companyReqData);
    
            res.status(201).send({ message: 'Company inserted successfully', data: result });
        } catch (err) {
            console.error(err);
            res.status(500).send({ message: 'Internal Server Error', data: err });
        }
    },

    updateCompanies: (req, res, next) => {
        const { company_id, company_name, company_url, post_panel_url, cms_url, description, status } = req.body;

        if (!company_id) {
            return res.status(400).send({ message: 'Invalid input. "company_id" is required.', data: null });
        }
        const updatedData = {};
        if (company_name !== undefined) updatedData.company_name = company_name;
        if (company_url !== undefined) updatedData.company_url = company_url;
        if (post_panel_url !== undefined) updatedData.post_panel_url = JSON.stringify(post_panel_url);
        if (cms_url !== undefined) updatedData.cms_url = cms_url;
        if (description !== undefined) updatedData.description = description;
        if (status !== undefined) updatedData.status = status;

        CompanyData.updateCompany(company_id, updatedData, (err, result) => {
            if (err) {
                const { statusCode = 500, message = 'Internal Server Error', data = null } = err;
                return res.status(statusCode).send({ message, data });
            }

            if (result.affectedRows === 0) {
                return res.status(404).send({ message: 'Company not found.', data: null });
            }

            const statusCode = 200;
            const message = 'Company updated successfully';
            const data = result;
            res.status(statusCode).send({ message, data });
        });
    },

};

module.exports = companiesController;
